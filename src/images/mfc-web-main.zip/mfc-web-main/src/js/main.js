$(window).scroll(function() {    
    var scroll = $(window).scrollTop();
    if (scroll >= 235) {
      $(".header-otr").addClass("slim-header");
    } else {
      $(".header-otr").removeClass("slim-header");
          }
   });
  

   

$('.hero-sesction').slick({
    infinite: true,
    speed: 300,
    fade: true,
    cssEase: 'linear',
    prevArrow: true,
    nextArrow: true,
    autoplay: true,
    autoplaySpeed: 3000,
    arrows: true,
    prevArrow: $('.prev'),
    nextArrow: $('.next'),
  });

  //FAQ

  let contentBox = document.querySelectorAll('.content-box');

for(i=0; i<contentBox.length; i++){
  contentBox[i].addEventListener('click', function(){
        this.classList.toggle('active')
  });
}


$('.containerSliderr').slick({
  infinite: true,
  slidesToShow: 3,
  slidesToScroll: 1,
  speed: 300,
  fade: true,
  cssEase: 'linear',
  prevArrow: true,
  nextArrow: true,
  autoplay: true,
  autoplaySpeed: 3000,
  arrows: true,
  prevArrow: $('.prev'),
  nextArrow: $('.next'),
});

$('.containerSlider').slick({
  infinite: false,
  slidesToShow: 3,
  slidesToScroll: 3,
  arrows: true,
  dots:false,
  responsive: [
    {
      breakpoint: 1199,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
        infinite: true,
      }
    },
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
        arrows: false,
        dots:true,
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        dots:true,
      }
    }
  ]
});
	